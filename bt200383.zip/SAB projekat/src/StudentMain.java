import java.math.BigDecimal;
import java.util.List;
import rs.etf.sab.operations.*;
import rs.etf.sab.tests.*;
import student.*;


public class StudentMain {
    
    static double euclidean(int x1, int y1, int x2, int y2) {
      return Math.sqrt((double)((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)));
      
    }

    static BigDecimal getPackagePrice(int type, BigDecimal weight, double distance, BigDecimal percentage) {
        percentage = percentage.divide(new BigDecimal(100));
          switch(type) {
          case 0:
             return (new BigDecimal(10.0D * distance)).multiply(percentage.add(new BigDecimal(1)));
          case 1:
             return (new BigDecimal((25.0D + weight.doubleValue() * 100.0D) * distance)).multiply(percentage.add(new BigDecimal(1)));
          case 2:
             return (new BigDecimal((75.0D + weight.doubleValue() * 300.0D) * distance)).multiply(percentage.add(new BigDecimal(1)));
          default:
             return null;
          }
    }

    public static void main(String[] args) {
        CityOperations cityOperations = new bt200383_CityOperations(); // Change this to your implementation.
        DistrictOperations districtOperations = new bt200383_DistrictOperations(); // Do it for all classes.
        CourierOperations courierOperations = new bt200383_CourierOperations(); // e.g. = new MyDistrictOperations();
        CourierRequestOperation courierRequestOperation = new bt200383_CourierRequestOperation();
        GeneralOperations generalOperations = new bt200383_GeneralOperations();
        UserOperations userOperations = new bt200383_UserOperations();
        VehicleOperations vehicleOperations = new bt200383_VehicleOperations();
        PackageOperations packageOperations = new bt200383_PackageOperations();
        
        
        TestHandler.createInstance(
            cityOperations,
            courierOperations,
            courierRequestOperation,
            districtOperations,
            generalOperations,
            userOperations,
            vehicleOperations,
            packageOperations);
        TestRunner.runTests();
        
    }
}
